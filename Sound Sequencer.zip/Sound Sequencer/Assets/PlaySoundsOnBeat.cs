﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlaySoundsOnBeat : MonoBehaviour {
    public SoundManager soundManager;
    public AudioClip[] wood, stone, copper, farm, iron, forge, steel, gold, diamond, mithril, obsidian, market;


	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        if(BPerM.beatFull)
		
	}
}
