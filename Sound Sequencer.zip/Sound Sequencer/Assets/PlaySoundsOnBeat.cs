﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlaySoundsOnBeat : MonoBehaviour {
    public SoundManager soundManager;
    public AudioClip chop;
    //public AudioClip[] chop;


	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        if(BPerM.beatFull)
        {
            soundManager.PlaySound(chop, 1);
            ResourceGeneration.wood = ResourceGeneration.wood + ResourceGeneration.woodGeneration;
            Debug.Log("How much wood you have: " + ResourceGeneration.wood);

            if (ResourceGeneration.wood >= 10)
            {
                Upgrades.stoneUpgrade1 = true;
                Debug.Log("Stone upgrade is available");
            }

        }

		
	}
}
