﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ResourceGeneration : MonoBehaviour {

    public static float wood;
    public static float iron;
    public static float woodGeneration = 1;
    public static float stoneGeneration;



	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        while (wood >= 10)
        {
            Upgrades.stoneUpgrade1 = true;
            Debug.Log("Stone upgrade is available");
        }

    }

}

