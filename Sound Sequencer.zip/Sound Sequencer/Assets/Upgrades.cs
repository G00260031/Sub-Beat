﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Upgrades : MonoBehaviour
{

    public static bool woodUpgrade1 = false;
    public static bool woodUpgrade2 = false;
    public static bool woodUpgrade3 = false;
    public static bool woodUpgrade4 = false;
    public static bool woodUpgrade5 = false;
    public static bool woodUpgrade6 = false;
    public static bool woodUpgrade7 = false;
    public static bool woodUpgrade8 = false;
    public static bool woodUpgrade9 = false;
    public static bool woodUpgrade10 = false;
    public static bool stoneUpgrade1 = false;
    public static bool stoneUpgrade2 = false;
    public static bool stoneUpgrade3= false;
    public static bool stoneUpgrade4 = false;
    public static bool stoneUpgrade5 = false;
    public static bool stoneUpgrade6 = false;
    public static bool stoneUpgrade7 = false;
    public static bool stoneUpgrade8 = false;
    public static bool stoneUpgrade9 = false;
    public static bool stoneUpgrade10 = false;
    public static bool copperUpgrade1 = false;
    public static bool copperUpgrade2 = false;
    public static bool copperUpgrade3 = false;
    public static bool copperUpgrade4 = false;
    public static bool copperUpgrade5 = false;
    public static bool copperUpgrade6 = false;
    public static bool copperUpgrade7 = false;
    public static bool copperUpgrade8 = false;
    public static bool copperUpgrade9 = false;
    public static bool copperUpgrade10 = false;
    public static bool ironUpgrade1 = false;
    public static bool ironUpgrade2 = false;
    public static bool ironUpgrade3 = false;
    public static bool farmUpgrade1 = false;
    public static bool farmUpgrade2 = false;
    public static bool farmUpgrade3 = false;
    public static bool forgeUpgrade1 = false;
    public static bool forgeUpgrade2 = false;
    public static bool forgeUpgrade3 = false;
    public static bool goldUpgrade1 = false;
    public static bool goldUpgrade2 = false;
    public static bool goldUpgrade3 = false;
    public static bool diamondUpgrade1 = false;
    public static bool diamondUpgrade2 = false;
    public static bool diamondUpgrade3 = false;
    public static bool mithrilUpgrade1 = false;
    public static bool mithrilUpgrade2 = false;
    public static bool mithrilUpgrade3 = false;
    public static bool obsidianUpgrade1 = false;
    public static bool obsidianUpgrade2 = false;
    public static bool obsidianUpgrade3 = false;
    public static bool marketUpgrade1 = false;
    public static bool marketUpgrade2 = false;
    public static bool marketUpgrade3 = false;
    public static bool sawmillUpgrade1 = false;
    public static bool sawmillUpgrade2 = false;
    public static bool sawmillUpgrade3 = false;




    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {


    }
}
